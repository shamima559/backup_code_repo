#include <iostream>

using namespace std;

int main()
{
    int v, t;
   
    while (cin >> v >> t)
    {
        cout << (2 * v * t) << '\n';
    }
}