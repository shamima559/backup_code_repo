#include <iostream>

using namespace std;

int main()
{
    string temp;
    while (getline(cin, temp))
    {
        cout << temp << '\n';
    }

}