#include <cstdio>

int main()
{
    printf("KABIR\n");
}