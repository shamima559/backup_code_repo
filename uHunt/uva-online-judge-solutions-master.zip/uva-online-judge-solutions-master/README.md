UVA Online Judge Solutions
===========================

This repository contains my ACCEPTED solutions for many UVA online judge problems. In many solutions, I have added comments on my solution approach and high level logic so that you can follow it easily. Feel free to read the source codes if you get stuck on some problems for many hours, or use them to generate sample outputs for your testing.

If you have feedback on my solutions, or you want to share alternative solutions, you can contact me at truongduy134@gmail.com.

You can also see latest UVA problems that I solve at http://uhunt.felix-halim.net/id/72911
