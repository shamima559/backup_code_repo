#include <cstdio>
#include <vector>
#include <cmath>

using namespace std;

bool isSquare(int n)
{
	int sqRoot = (int) floor(sqrt(n));
	if(sqRoot * sqRoot == n)
		return true;
	return false;
}

int main(void)
{
	int numPeg, T;

	scanf("%d
	return 0;	
}
